# =============================================================================
# VARLIK YONETIMI - Bu fonksiyonu dashboard.py'deki ayni fonksiyonun yerine yapistir
# Satir 839 civarinda basliyor
# =============================================================================

def safe_float(value, default=0.0):
    """Guvenli float donusumu."""
    if value is None:
        return default
    try:
        return float(value)
    except (ValueError, TypeError):
        return default


def render_asset_management_page():
    """Varlik yonetimi sayfasi."""
    st.markdown("## Varlik Yonetimi")
    
    config = st.session_state.config
    if not config:
        st.warning("Once sol menuden Yukle butonuna basin.")
        return
    
    # Session state for add forms
    if 'show_add_tefas' not in st.session_state:
        st.session_state.show_add_tefas = False
    if 'show_add_us' not in st.session_state:
        st.session_state.show_add_us = False
    if 'show_add_crypto' not in st.session_state:
        st.session_state.show_add_crypto = False
    if 'show_add_cash' not in st.session_state:
        st.session_state.show_add_cash = False
    
    tab1, tab2, tab3, tab4 = st.tabs(["TEFAS", "ABD Hisse", "Kripto", "Nakit"])
    
    # ========== TEFAS ==========
    with tab1:
        st.markdown("### TEFAS Fonlari")
        
        if not config.tefas_funds:
            st.info("Henuz TEFAS fonu eklenmemis.")
        
        for i, fund in enumerate(config.tefas_funds):
            col1, col2, col3, col4 = st.columns([2, 2, 1, 0.5])
            with col1:
                config.tefas_funds[i]['code'] = st.text_input(
                    "Kod", fund.get('code', ''), key=f"tefas_code_{i}", label_visibility="collapsed"
                )
            with col2:
                config.tefas_funds[i]['shares'] = st.number_input(
                    "Adet", safe_float(fund.get('shares', 0)), key=f"tefas_shares_{i}", label_visibility="collapsed",
                    min_value=0.0, step=1.0
                )
            with col3:
                config.tefas_funds[i]['target_weight'] = st.number_input(
                    "Hedef", safe_float(fund.get('target_weight', 0)), key=f"tefas_weight_{i}", 
                    label_visibility="collapsed", min_value=0.0, max_value=100.0
                )
            with col4:
                if st.button("Sil", key=f"del_tefas_{i}"):
                    config.tefas_funds.pop(i)
                    st.rerun()
        
        st.markdown("---")
        
        # Yeni ekleme formu
        if st.button("+ TEFAS Ekle", key="btn_add_tefas"):
            st.session_state.show_add_tefas = not st.session_state.show_add_tefas
        
        if st.session_state.show_add_tefas:
            col1, col2, col3 = st.columns([2, 2, 1])
            with col1:
                new_code = st.text_input("Fon Kodu", placeholder="TCD, AFT", key="new_tefas_code")
            with col2:
                new_shares = st.number_input("Adet", min_value=0.0, step=1.0, key="new_tefas_shares")
            with col3:
                new_weight = st.number_input("Hedef %", min_value=0.0, max_value=100.0, key="new_tefas_weight")
            
            if st.button("Ekle", key="confirm_add_tefas", type="primary"):
                if new_code:
                    config.tefas_funds.append({
                        'code': new_code.upper(),
                        'shares': new_shares,
                        'target_weight': new_weight
                    })
                    st.session_state.show_add_tefas = False
                    st.rerun()
    
    # ========== ABD HISSE ==========
    with tab2:
        st.markdown("### ABD Hisseleri")
        
        if not config.us_stocks:
            st.info("Henuz ABD hissesi eklenmemis.")
        
        for i, stock in enumerate(config.us_stocks):
            col1, col2, col3, col4 = st.columns([2, 2, 1, 0.5])
            with col1:
                config.us_stocks[i]['ticker'] = st.text_input(
                    "Ticker", stock.get('ticker', ''), key=f"us_ticker_{i}", label_visibility="collapsed"
                )
            with col2:
                config.us_stocks[i]['shares'] = st.number_input(
                    "Adet", safe_float(stock.get('shares', 0)), key=f"us_shares_{i}", label_visibility="collapsed",
                    min_value=0.0, step=0.01
                )
            with col3:
                config.us_stocks[i]['target_weight'] = st.number_input(
                    "Hedef", safe_float(stock.get('target_weight', 0)), key=f"us_weight_{i}",
                    label_visibility="collapsed", min_value=0.0, max_value=100.0
                )
            with col4:
                if st.button("Sil", key=f"del_us_{i}"):
                    config.us_stocks.pop(i)
                    st.rerun()
        
        st.markdown("---")
        
        if st.button("+ Hisse Ekle", key="btn_add_us"):
            st.session_state.show_add_us = not st.session_state.show_add_us
        
        if st.session_state.show_add_us:
            col1, col2, col3 = st.columns([2, 2, 1])
            with col1:
                new_ticker = st.text_input("Ticker", placeholder="AAPL, GOOGL", key="new_us_ticker")
            with col2:
                new_shares = st.number_input("Adet", min_value=0.0, step=0.01, key="new_us_shares")
            with col3:
                new_weight = st.number_input("Hedef %", min_value=0.0, max_value=100.0, key="new_us_weight")
            
            if st.button("Ekle", key="confirm_add_us", type="primary"):
                if new_ticker:
                    config.us_stocks.append({
                        'ticker': new_ticker.upper(),
                        'shares': new_shares,
                        'target_weight': new_weight
                    })
                    st.session_state.show_add_us = False
                    st.rerun()
    
    # ========== KRIPTO ==========
    with tab3:
        st.markdown("### Kripto Varliklar")
        
        if not config.crypto:
            st.info("Henuz kripto varlik eklenmemis.")
        
        for i, crypto in enumerate(config.crypto):
            col1, col2, col3, col4 = st.columns([2, 2, 1, 0.5])
            with col1:
                config.crypto[i]['symbol'] = st.text_input(
                    "Symbol", crypto.get('symbol', ''), key=f"crypto_symbol_{i}", label_visibility="collapsed"
                )
            with col2:
                config.crypto[i]['amount'] = st.number_input(
                    "Miktar", safe_float(crypto.get('amount', 0)), key=f"crypto_amount_{i}", label_visibility="collapsed",
                    min_value=0.0, step=0.0001, format="%.4f"
                )
            with col3:
                config.crypto[i]['target_weight'] = st.number_input(
                    "Hedef", safe_float(crypto.get('target_weight', 0)), key=f"crypto_weight_{i}",
                    label_visibility="collapsed", min_value=0.0, max_value=100.0
                )
            with col4:
                if st.button("Sil", key=f"del_crypto_{i}"):
                    config.crypto.pop(i)
                    st.rerun()
        
        st.markdown("---")
        
        if st.button("+ Kripto Ekle", key="btn_add_crypto"):
            st.session_state.show_add_crypto = not st.session_state.show_add_crypto
        
        if st.session_state.show_add_crypto:
            col1, col2, col3 = st.columns([2, 2, 1])
            with col1:
                new_symbol = st.text_input("Symbol", placeholder="BTC, ETH", key="new_crypto_symbol")
            with col2:
                new_amount = st.number_input("Miktar", min_value=0.0, step=0.0001, format="%.4f", key="new_crypto_amount")
            with col3:
                new_weight = st.number_input("Hedef %", min_value=0.0, max_value=100.0, key="new_crypto_weight")
            
            if st.button("Ekle", key="confirm_add_crypto", type="primary"):
                if new_symbol:
                    config.crypto.append({
                        'symbol': new_symbol.upper(),
                        'amount': new_amount,
                        'target_weight': new_weight
                    })
                    st.session_state.show_add_crypto = False
                    st.rerun()
    
    # ========== NAKIT ==========
    with tab4:
        st.markdown("### Nakit Varliklar")
        
        if not config.cash:
            st.info("Henuz nakit varlik eklenmemis.")
        
        for i, cash in enumerate(config.cash):
            col1, col2, col3 = st.columns([2, 2, 0.5])
            with col1:
                config.cash[i]['code'] = st.text_input(
                    "Kod", cash.get('code', ''), key=f"cash_code_{i}", label_visibility="collapsed"
                )
            with col2:
                config.cash[i]['amount'] = st.number_input(
                    "Miktar", safe_float(cash.get('amount', 0)), key=f"cash_amount_{i}", label_visibility="collapsed",
                    min_value=0.0, step=1.0
                )
            with col3:
                if st.button("Sil", key=f"del_cash_{i}"):
                    config.cash.pop(i)
                    st.rerun()
        
        st.markdown("---")
        
        if st.button("+ Nakit Ekle", key="btn_add_cash"):
            st.session_state.show_add_cash = not st.session_state.show_add_cash
        
        if st.session_state.show_add_cash:
            col1, col2 = st.columns([2, 2])
            with col1:
                new_code = st.text_input("Kod", placeholder="USD, DLY", key="new_cash_code")
            with col2:
                new_amount = st.number_input("Miktar", min_value=0.0, step=1.0, key="new_cash_amount")
            
            if st.button("Ekle", key="confirm_add_cash", type="primary"):
                if new_code:
                    config.cash.append({
                        'code': new_code.upper(),
                        'amount': new_amount
                    })
                    st.session_state.show_add_cash = False
                    st.rerun()
    
    # ========== KAYDET ==========
    st.markdown("---")
    col1, col2 = st.columns([3, 1])
    with col1:
        if st.button("Tumunu Kaydet", type="primary", use_container_width=True):
            if save_config_to_cloud(config):
                st.success("Portfolio kaydedildi!")
                st.session_state.portfolio = Portfolio(config)
            else:
                st.error("Kaydetme hatasi!")
    
    with col2:
        total_assets = len(config.tefas_funds) + len(config.us_stocks) + len(config.crypto) + len(config.cash)
        st.metric("Toplam", total_assets)
