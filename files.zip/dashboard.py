"""
dashboard.py - Portföy Dashboard Ana Uygulaması (v2)
====================================================

Streamlit tabanlı interaktif web dashboard.

Güncellemeler v2:
- Çoklu sayfa navigasyonu (Dashboard / Varlık Yönetimi / Ayarlar)
- Geliştirilmiş UI/UX
- Varlık seçim entegrasyonu

Kullanım:
    streamlit run dashboard.py

Yazar: Portfolio Dashboard
Tarih: Ocak 2026
"""

import logging
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from portfolio import (
    Portfolio,
    PortfolioConfig,
    format_currency,
    format_percentage,
    load_config,
)
from asset_selector import render_asset_selector

# =============================================================================
# SAYFA AYARLARI
# =============================================================================

st.set_page_config(
    page_title="Portföy Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# =============================================================================
# STIL
# =============================================================================

st.markdown("""
<style>
    /* Ana tema */
    .main-title {
        font-size: 2.5rem;
        font-weight: 700;
        color: #1a1a2e;
        margin-bottom: 0.5rem;
    }
    
    .subtitle {
        font-size: 1rem;
        color: #666;
        margin-bottom: 2rem;
    }
    
    /* Pozitif/negatif renkler */
    .positive { color: #00d26a !important; }
    .negative { color: #ff6b6b !important; }
    
    /* Navigasyon butonları */
    .nav-button {
        padding: 10px 20px;
        border-radius: 10px;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s;
    }
    
    /* Kart stilleri */
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 15px;
        padding: 20px;
        color: white;
    }
    
    /* Sidebar navigasyon */
    .sidebar-nav {
        padding: 10px;
        margin: 5px 0;
        border-radius: 8px;
        cursor: pointer;
    }
    
    .sidebar-nav:hover {
        background-color: #f0f2f6;
    }
    
    .sidebar-nav.active {
        background-color: #667eea;
        color: white;
    }
</style>
""", unsafe_allow_html=True)


# =============================================================================
# SESSION STATE
# =============================================================================

def init_session_state():
    """Session state'i başlat."""
    if 'portfolio' not in st.session_state:
        st.session_state.portfolio = None
    if 'config' not in st.session_state:
        st.session_state.config = None
    if 'last_refresh' not in st.session_state:
        st.session_state.last_refresh = None
    if 'current_page' not in st.session_state:
        st.session_state.current_page = "dashboard"


# =============================================================================
# SIDEBAR
# =============================================================================

def render_sidebar():
    """Sidebar'ı render et."""
    with st.sidebar:
        st.markdown("# 📊 Portföy")
        st.markdown("---")
        
        # Navigasyon
        st.markdown("### 📍 Navigasyon")
        
        if st.button("🏠 Dashboard", use_container_width=True, 
                    type="primary" if st.session_state.current_page == "dashboard" else "secondary"):
            st.session_state.current_page = "dashboard"
            st.rerun()
        
        if st.button("📦 Varlık Yönetimi", use_container_width=True,
                    type="primary" if st.session_state.current_page == "assets" else "secondary"):
            st.session_state.current_page = "assets"
            st.rerun()
        
        if st.button("⚙️ Ayarlar", use_container_width=True,
                    type="primary" if st.session_state.current_page == "settings" else "secondary"):
            st.session_state.current_page = "settings"
            st.rerun()
        
        st.markdown("---")
        
        # Hızlı işlemler (sadece dashboard sayfasında)
        if st.session_state.current_page == "dashboard":
            st.markdown("### 🔧 İşlemler")
            
            config_path = st.text_input(
                "Config Dosyası",
                value="config.yaml",
                label_visibility="collapsed"
            )
            
            col1, col2 = st.columns(2)
            
            with col1:
                if st.button("📥 Yükle", use_container_width=True):
                    with st.spinner("Yükleniyor..."):
                        st.session_state.config = load_config(config_path)
                        st.session_state.portfolio = Portfolio(st.session_state.config)
                        st.success("✓")
            
            with col2:
                if st.button("🔄 Güncelle", use_container_width=True, type="primary"):
                    if st.session_state.portfolio:
                        with st.spinner("Fiyatlar..."):
                            success = st.session_state.portfolio.refresh_prices()
                            if success:
                                st.session_state.last_refresh = datetime.now()
                                st.success("✓")
                            else:
                                st.error("!")
                    else:
                        st.warning("Önce yükle!")
            
            st.markdown("---")
        
        # Durum bilgisi
        if st.session_state.last_refresh:
            st.caption(f"Son güncelleme: {st.session_state.last_refresh.strftime('%H:%M:%S')}")
        
        # Portföy özeti
        if st.session_state.config:
            st.markdown("### 📋 Özet")
            cfg = st.session_state.config
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("TEFAS", len(cfg.tefas_funds))
                st.metric("Kripto", len(cfg.crypto))
            with col2:
                st.metric("ABD", len(cfg.us_stocks))
                st.metric("RF%", f"{cfg.risk_free_rate*100:.0f}")


# =============================================================================
# METRİK KARTLARI
# =============================================================================

def render_metric_cards(portfolio: Portfolio):
    """Özet metrik kartlarını render et."""
    metrics = portfolio.metrics
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="💰 Toplam Değer",
            value=format_currency(metrics.total_value_try),
        )
    
    with col2:
        weekly_return = metrics.weekly_return_pct
        delta_color = "normal" if weekly_return >= 0 else "inverse"
        st.metric(
            label="📈 Haftalık",
            value=format_percentage(weekly_return),
            delta=f"{weekly_return:+.2f}%",
            delta_color=delta_color
        )
    
    with col3:
        sharpe = metrics.sharpe_ratio
        if sharpe is not None:
            sharpe_display = f"{sharpe:.2f}"
            sharpe_icon = "🟢" if sharpe > 1 else "🟡" if sharpe > 0 else "🔴"
        else:
            sharpe_display = "N/A"
            sharpe_icon = "⚪"
        st.metric(label=f"Sharpe {sharpe_icon}", value=sharpe_display)
    
    with col4:
        vol = metrics.volatility_monthly
        if vol is not None:
            vol_display = f"%{vol:.1f}"
            vol_icon = "🟢" if vol < 10 else "🟡" if vol < 20 else "🔴"
        else:
            vol_display = "N/A"
            vol_icon = "⚪"
        st.metric(label=f"Volatilite {vol_icon}", value=vol_display)
    
    if metrics.warnings:
        st.warning("⚠️ " + " • ".join(metrics.warnings))


# =============================================================================
# VARLIK TABLOSU
# =============================================================================

def render_asset_table(portfolio: Portfolio):
    """Varlık tablosunu render et."""
    st.markdown("### 📋 Varlık Detayları")
    
    df = portfolio.get_summary_dataframe()
    
    if df.empty:
        st.info("Varlık verisi bulunamadı.")
        return
    
    def color_returns(val):
        if isinstance(val, (int, float)):
            if val > 0:
                return 'color: #00d26a'
            elif val < 0:
                return 'color: #ff6b6b'
        return ''
    
    format_dict = {
        'Fiyat': '{:.4f}',
        'Değer (TRY)': '₺{:,.2f}',
        'Ağırlık (%)': '{:.2f}%',
        'Hedef (%)': '{:.1f}%',
        'Sapma (%)': '{:+.2f}%',
        'Haftalık (%)': '{:+.2f}%',
        'Adet': '{:.4f}'
    }
    
    styled_df = df.style.map(color_returns, subset=['Haftalık (%)']).format(format_dict, na_rep='N/A')
    
    st.dataframe(styled_df, use_container_width=True, height=400)
    
    csv = df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 CSV İndir",
        data=csv,
        file_name=f"portfolio_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
        mime="text/csv"
    )


# =============================================================================
# GRAFİKLER
# =============================================================================

def render_charts(portfolio: Portfolio):
    """Grafikleri render et."""
    df = portfolio.get_summary_dataframe()
    df_valid = df[df['Değer (TRY)'] > 0]
    
    if df_valid.empty:
        st.info("Görselleştirme için veri yok.")
        return
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 🥧 Dağılım")
        
        fig = px.pie(
            df_valid,
            values='Değer (TRY)',
            names='Kod',
            hole=0.4,
            color_discrete_sequence=px.colors.qualitative.Set3
        )
        fig.update_traces(textposition='inside', textinfo='percent+label')
        fig.update_layout(showlegend=False, margin=dict(t=20, b=20, l=20, r=20))
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("### 📊 Haftalık Getiri")
        
        df_sorted = df_valid[df_valid['Haftalık (%)'].notna()].sort_values('Haftalık (%)')
        colors = ['#ff6b6b' if x < 0 else '#00d26a' for x in df_sorted['Haftalık (%)']]
        
        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=df_sorted['Kod'],
            y=df_sorted['Haftalık (%)'],
            marker_color=colors,
            text=[f"{v:+.1f}%" for v in df_sorted['Haftalık (%)']],
            textposition='outside'
        ))
        fig.update_layout(
            showlegend=False,
            yaxis=dict(zeroline=True, zerolinewidth=2, zerolinecolor='gray'),
            margin=dict(t=20, b=50)
        )
        st.plotly_chart(fig, use_container_width=True)
    
    # Trend grafiği
    st.markdown("### 📈 Fiyat Trendi")
    
    asset_codes = [a.code for a in portfolio.assets if a.is_valid]
    
    if asset_codes:
        selected_asset = st.selectbox("Varlık Seçin", options=asset_codes, index=0)
        
        with st.spinner(f"{selected_asset} verisi çekiliyor..."):
            hist_df = portfolio.get_history_data(selected_asset, days=30)
        
        if not hist_df.empty and len(hist_df) >= 2:
            fig = go.Figure()
            
            fig.add_trace(go.Scatter(
                x=hist_df['Date'],
                y=hist_df['Close'],
                mode='lines+markers',
                name=selected_asset,
                line=dict(color='#667eea', width=2),
                marker=dict(size=4)
            ))
            
            if len(hist_df) >= 7:
                hist_df['MA7'] = hist_df['Close'].rolling(window=7).mean()
                fig.add_trace(go.Scatter(
                    x=hist_df['Date'],
                    y=hist_df['MA7'],
                    mode='lines',
                    name='7G ORT',
                    line=dict(color='orange', width=1, dash='dash')
                ))
            
            fig.update_layout(
                hovermode='x unified',
                legend=dict(orientation="h", yanchor="bottom", y=1.02),
                margin=dict(t=40, b=40)
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning(f"{selected_asset} için geçmiş veri bulunamadı.")


# =============================================================================
# KORELASYON
# =============================================================================

def render_correlation(portfolio: Portfolio):
    """Korelasyon matrisini render et."""
    st.markdown("### 🔗 Korelasyon Matrisi")
    
    corr_matrix = portfolio.get_correlation_matrix()
    
    if corr_matrix is None or corr_matrix.empty:
        st.info("Korelasyon matrisi hesaplanamadı (yetersiz veri).")
        return
    
    fig = px.imshow(
        corr_matrix,
        text_auto='.2f',
        color_continuous_scale='RdBu_r',
        zmin=-1, zmax=1,
        aspect='auto'
    )
    fig.update_layout(margin=dict(t=20, b=20))
    st.plotly_chart(fig, use_container_width=True)
    
    st.caption("🟢 Düşük korelasyon = İyi çeşitlendirme | 🔴 Yüksek korelasyon = Risk")


# =============================================================================
# REBALANCING
# =============================================================================

def render_rebalancing(portfolio: Portfolio):
    """Rebalancing önerilerini render et."""
    st.markdown("### ⚖️ Rebalancing Önerileri")
    
    suggestions = portfolio.get_rebalancing_suggestions()
    
    if not suggestions:
        st.success("✅ Portföy dengede!")
        return
    
    cols = st.columns(min(len(suggestions), 4))
    
    for idx, sugg in enumerate(suggestions[:8]):
        with cols[idx % 4]:
            action_color = "#00d26a" if sugg['action'] == 'AL' else "#ff6b6b"
            action_icon = "🟢" if sugg['action'] == 'AL' else "🔴"
            
            st.markdown(f"""
            <div style="
                border: 2px solid {action_color};
                border-radius: 10px;
                padding: 12px;
                margin: 5px 0;
                text-align: center;
            ">
                <h4 style="margin: 0;">{action_icon} {sugg['code']}</h4>
                <p style="margin: 5px 0; font-size: 0.9rem;">
                    <strong>{sugg['action']}</strong>: {sugg['shares']:.2f} adet
                </p>
                <p style="margin: 0; font-size: 0.8rem; color: #888;">
                    ₺{sugg['value_try']:,.0f}
                </p>
            </div>
            """, unsafe_allow_html=True)


# =============================================================================
# SAYFA: DASHBOARD
# =============================================================================

def render_dashboard_page():
    """Dashboard ana sayfasını render et."""
    st.markdown("""
    <h1 class="main-title">📊 Portföy Dashboard</h1>
    <p class="subtitle">Gerçek zamanlı portföy takibi ve analizi</p>
    """, unsafe_allow_html=True)
    
    portfolio = st.session_state.portfolio
    
    if portfolio is None:
        st.info("👈 Sol menüden config dosyasını yükleyin.")
        
        with st.expander("🚀 Hızlı Başlangıç"):
            st.markdown("""
            1. **Varlık Yönetimi** sayfasına gidin
            2. Portföyünüze hisse/kripto/fon ekleyin
            3. Config'i kaydedin
            4. Dashboard'a dönüp **Güncelle** butonuna basın
            """)
        return
    
    if not portfolio.assets or not any(a.is_valid for a in portfolio.assets):
        st.warning("⚠️ Varlık verisi yok. **Güncelle** butonuna basın.")
        return
    
    # Metrikler
    render_metric_cards(portfolio)
    
    st.markdown("---")
    
    # Tabs
    tab1, tab2, tab3, tab4 = st.tabs(["📋 Varlıklar", "📊 Grafikler", "🔗 Korelasyon", "⚖️ Rebalancing"])
    
    with tab1:
        render_asset_table(portfolio)
    
    with tab2:
        render_charts(portfolio)
    
    with tab3:
        render_correlation(portfolio)
    
    with tab4:
        render_rebalancing(portfolio)


# =============================================================================
# SAYFA: AYARLAR
# =============================================================================

def render_settings_page():
    """Ayarlar sayfasını render et."""
    st.markdown("## ⚙️ Ayarlar")
    
    st.markdown("### 🎨 Görünüm")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.selectbox("Tema", ["Koyu", "Açık", "Sistem"], index=0)
        st.selectbox("Dil", ["Türkçe", "English"], index=0)
    
    with col2:
        st.number_input("Otomatik yenileme (dk)", min_value=0, max_value=60, value=0)
        st.checkbox("Bildirimler", value=True)
    
    st.markdown("---")
    
    st.markdown("### 📊 Hesaplama Parametreleri")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.number_input("Risk-free rate (%)", min_value=0.0, max_value=100.0, value=35.0)
        st.number_input("Volatilite penceresi (gün)", min_value=5, max_value=90, value=21)
    
    with col2:
        st.number_input("Sharpe penceresi (gün)", min_value=5, max_value=365, value=252)
        st.number_input("Korelasyon penceresi (gün)", min_value=5, max_value=90, value=30)
    
    st.markdown("---")
    
    st.markdown("### 🔧 API Ayarları")
    
    st.text_input("Alpha Vantage API Key", value="ARHII442USE7XF12", type="password")
    st.number_input("Timeout (saniye)", min_value=5, max_value=120, value=30)
    
    st.markdown("---")
    
    if st.button("💾 Ayarları Kaydet", type="primary"):
        st.success("Ayarlar kaydedildi!")


# =============================================================================
# ANA UYGULAMA
# =============================================================================

def main():
    """Ana uygulama fonksiyonu."""
    init_session_state()
    
    # İlk yüklemede config'i otomatik yükle
    if st.session_state.config is None:
        config_path = Path("config.yaml")
        if config_path.exists():
            st.session_state.config = load_config(str(config_path))
            st.session_state.portfolio = Portfolio(st.session_state.config)
    
    # Sidebar
    render_sidebar()
    
    # Sayfa yönlendirme
    if st.session_state.current_page == "dashboard":
        render_dashboard_page()
    elif st.session_state.current_page == "assets":
        render_asset_selector()
    elif st.session_state.current_page == "settings":
        render_settings_page()


if __name__ == "__main__":
    main()
