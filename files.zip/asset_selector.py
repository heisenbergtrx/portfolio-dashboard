"""
asset_selector.py - Varlık Seçim Modülü
=======================================

Kullanıcının portföyüne varlık eklemesini sağlayan interaktif UI bileşenleri.

Özellikler:
- ABD hisse senedi arama (Alpha Vantage SYMBOL_SEARCH)
- Kripto para listesi (popüler coinler)
- TEFAS fon arama
- Seçilen varlıkları config'e kaydetme

Yazar: Portfolio Dashboard
Tarih: Ocak 2026
"""

import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import requests
import streamlit as st
import yaml

logger = logging.getLogger(__name__)

# Alpha Vantage API
ALPHA_VANTAGE_API_KEY = "ARHII442USE7XF12"
ALPHA_VANTAGE_BASE_URL = "https://www.alphavantage.co/query"

# Popüler kripto listesi
POPULAR_CRYPTOS = [
    {"symbol": "BTC/USDT", "name": "Bitcoin"},
    {"symbol": "ETH/USDT", "name": "Ethereum"},
    {"symbol": "SOL/USDT", "name": "Solana"},
    {"symbol": "BNB/USDT", "name": "Binance Coin"},
    {"symbol": "XRP/USDT", "name": "Ripple"},
    {"symbol": "ADA/USDT", "name": "Cardano"},
    {"symbol": "AVAX/USDT", "name": "Avalanche"},
    {"symbol": "DOGE/USDT", "name": "Dogecoin"},
    {"symbol": "DOT/USDT", "name": "Polkadot"},
    {"symbol": "MATIC/USDT", "name": "Polygon"},
    {"symbol": "LINK/USDT", "name": "Chainlink"},
    {"symbol": "UNI/USDT", "name": "Uniswap"},
    {"symbol": "ATOM/USDT", "name": "Cosmos"},
    {"symbol": "LTC/USDT", "name": "Litecoin"},
    {"symbol": "APT/USDT", "name": "Aptos"},
    {"symbol": "ARB/USDT", "name": "Arbitrum"},
    {"symbol": "OP/USDT", "name": "Optimism"},
    {"symbol": "NEAR/USDT", "name": "NEAR Protocol"},
    {"symbol": "FIL/USDT", "name": "Filecoin"},
    {"symbol": "INJ/USDT", "name": "Injective"},
]

# Popüler TEFAS fonları
POPULAR_TEFAS = [
    {"code": "DLY", "name": "Deniz Portföy Para Piyasası Fonu"},
    {"code": "DIP", "name": "Deniz Portföy Kısa Vadeli Borçlanma Araçları"},
    {"code": "MET", "name": "İş Portföy BIST 30 Endeks HSY Fonu"},
    {"code": "AKF", "name": "Ak Portföy Kısa Vadeli Borçlanma Araçları"},
    {"code": "YAF", "name": "Yapı Kredi Portföy Altın Fonu"},
    {"code": "GAF", "name": "Garanti Portföy Altın Fonu"},
    {"code": "TI2", "name": "TEB Portföy İkinci Değişken Fon"},
    {"code": "IPB", "name": "İş Portföy BIST Banka Endeksi HSY Fonu"},
    {"code": "YEF", "name": "Yapı Kredi Portföy Yab. Tek. Sek. HSY Fonu"},
    {"code": "AFT", "name": "Ak Portföy Amerikan Teknoloji Yab. HSY Fonu"},
    {"code": "ZPX", "name": "Ziraat Portföy S&P 500 Yab. HSY Fonu"},
    {"code": "MAC", "name": "Marmara Capital Portföy Değişken Fonu"},
    {"code": "TPE", "name": "Tacirler Portföy Hisse Senedi Fonu"},
    {"code": "GZO", "name": "Garanti Portföy Birinci Değişken Fon"},
]

# Popüler ABD hisseleri
POPULAR_US_STOCKS = [
    {"ticker": "AAPL", "name": "Apple Inc."},
    {"ticker": "MSFT", "name": "Microsoft Corporation"},
    {"ticker": "GOOGL", "name": "Alphabet Inc."},
    {"ticker": "AMZN", "name": "Amazon.com Inc."},
    {"ticker": "NVDA", "name": "NVIDIA Corporation"},
    {"ticker": "META", "name": "Meta Platforms Inc."},
    {"ticker": "TSLA", "name": "Tesla Inc."},
    {"ticker": "BRK.B", "name": "Berkshire Hathaway"},
    {"ticker": "JPM", "name": "JPMorgan Chase & Co."},
    {"ticker": "V", "name": "Visa Inc."},
    {"ticker": "JNJ", "name": "Johnson & Johnson"},
    {"ticker": "WMT", "name": "Walmart Inc."},
    {"ticker": "MA", "name": "Mastercard Inc."},
    {"ticker": "PG", "name": "Procter & Gamble"},
    {"ticker": "HD", "name": "Home Depot Inc."},
    {"ticker": "DIS", "name": "Walt Disney Co."},
    {"ticker": "NFLX", "name": "Netflix Inc."},
    {"ticker": "AMD", "name": "AMD Inc."},
    {"ticker": "INTC", "name": "Intel Corporation"},
    {"ticker": "CRM", "name": "Salesforce Inc."},
    {"ticker": "ORCL", "name": "Oracle Corporation"},
    {"ticker": "CSCO", "name": "Cisco Systems"},
    {"ticker": "ADBE", "name": "Adobe Inc."},
    {"ticker": "PYPL", "name": "PayPal Holdings"},
    {"ticker": "COIN", "name": "Coinbase Global"},
    {"ticker": "SQ", "name": "Block Inc. (Square)"},
    {"ticker": "PLTR", "name": "Palantir Technologies"},
    {"ticker": "SOFI", "name": "SoFi Technologies"},
    {"ticker": "NIO", "name": "NIO Inc."},
    {"ticker": "BABA", "name": "Alibaba Group"},
]


def search_us_stocks(query: str, api_key: str = ALPHA_VANTAGE_API_KEY) -> list[dict]:
    """
    Alpha Vantage SYMBOL_SEARCH ile ABD hissesi ara.
    """
    if not query or len(query) < 1:
        return []
    
    try:
        url = f"{ALPHA_VANTAGE_BASE_URL}?function=SYMBOL_SEARCH&keywords={query}&apikey={api_key}"
        response = requests.get(url, timeout=10)
        data = response.json()
        
        if "bestMatches" in data:
            results = []
            for match in data["bestMatches"][:10]:
                # Sadece ABD hisseleri
                if match.get("4. region") == "United States":
                    results.append({
                        "ticker": match.get("1. symbol"),
                        "name": match.get("2. name"),
                        "type": match.get("3. type"),
                        "region": match.get("4. region")
                    })
            return results
        return []
        
    except Exception as e:
        logger.error(f"Hisse arama hatası: {e}")
        return []


def load_config(config_path: str = "config.yaml") -> dict:
    """Config dosyasını yükle."""
    config_file = Path(config_path)
    
    if config_file.exists():
        with open(config_file, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f) or {}
    
    return {
        "settings": {
            "risk_free_rate": 0.35,
            "cache_ttl_seconds": 3600,
            "fetch_timeout_seconds": 30,
            "log_level": "INFO"
        },
        "thresholds": {
            "weekly_loss_threshold": -4.0,
            "weekly_gain_threshold": 7.0,
            "weight_deviation_threshold": 5.0,
            "high_volatility_threshold": 15.0,
            "high_correlation_threshold": 0.7
        },
        "tefas_funds": [],
        "us_stocks": [],
        "crypto": []
    }


def save_config(config: dict, config_path: str = "config.yaml") -> bool:
    """Config dosyasını kaydet."""
    try:
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.dump(config, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
        return True
    except Exception as e:
        logger.error(f"Config kaydetme hatası: {e}")
        return False


def render_asset_selector():
    """Varlık seçim sayfasını render et."""
    
    st.markdown("## 📦 Portföy Yönetimi")
    st.markdown("Portföyünüze varlık ekleyin, düzenleyin veya kaldırın.")
    
    # Config yükle
    if 'portfolio_config' not in st.session_state:
        st.session_state.portfolio_config = load_config()
    
    config = st.session_state.portfolio_config
    
    # Tab yapısı
    tab1, tab2, tab3, tab4 = st.tabs([
        "🇺🇸 ABD Hisseleri",
        "₿ Kripto",
        "🇹🇷 TEFAS Fonları",
        "💾 Kaydet & Özet"
    ])
    
    # =========================================================================
    # TAB 1: ABD HİSSELERİ
    # =========================================================================
    with tab1:
        st.markdown("### ABD Hisse Senetleri")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            # Arama kutusu
            search_query = st.text_input(
                "🔍 Hisse Ara (ticker veya şirket adı)",
                placeholder="Örn: AAPL, Apple, Tesla...",
                key="us_stock_search"
            )
            
            # Arama sonuçları
            if search_query:
                with st.spinner("Aranıyor..."):
                    results = search_us_stocks(search_query)
                
                if results:
                    st.markdown("**Arama Sonuçları:**")
                    for result in results:
                        col_r1, col_r2, col_r3 = st.columns([2, 4, 1])
                        with col_r1:
                            st.code(result['ticker'])
                        with col_r2:
                            st.write(result['name'][:40])
                        with col_r3:
                            if st.button("➕", key=f"add_us_{result['ticker']}"):
                                # Ekle
                                existing = [s['ticker'] for s in config.get('us_stocks', [])]
                                if result['ticker'] not in existing:
                                    if 'us_stocks' not in config:
                                        config['us_stocks'] = []
                                    config['us_stocks'].append({
                                        'ticker': result['ticker'],
                                        'shares': 1.0,
                                        'target_weight': 5.0
                                    })
                                    st.success(f"{result['ticker']} eklendi!")
                                    st.rerun()
                                else:
                                    st.warning("Zaten listede!")
                else:
                    st.info("Sonuç bulunamadı. Başka bir terim deneyin.")
        
        with col2:
            st.markdown("**Popüler Hisseler:**")
            for stock in POPULAR_US_STOCKS[:10]:
                existing = [s['ticker'] for s in config.get('us_stocks', [])]
                disabled = stock['ticker'] in existing
                
                if st.button(
                    f"{stock['ticker']}", 
                    key=f"pop_us_{stock['ticker']}",
                    disabled=disabled,
                    help=stock['name']
                ):
                    if 'us_stocks' not in config:
                        config['us_stocks'] = []
                    config['us_stocks'].append({
                        'ticker': stock['ticker'],
                        'shares': 1.0,
                        'target_weight': 5.0
                    })
                    st.rerun()
        
        # Mevcut seçimler
        st.markdown("---")
        st.markdown("### 📋 Seçili ABD Hisseleri")
        
        if config.get('us_stocks'):
            for idx, stock in enumerate(config['us_stocks']):
                col1, col2, col3, col4 = st.columns([2, 2, 2, 1])
                
                with col1:
                    st.markdown(f"**{stock['ticker']}**")
                
                with col2:
                    new_shares = st.number_input(
                        "Adet",
                        min_value=0.0,
                        value=float(stock.get('shares', 1)),
                        step=1.0,
                        key=f"shares_us_{idx}",
                        label_visibility="collapsed"
                    )
                    config['us_stocks'][idx]['shares'] = new_shares
                
                with col3:
                    new_weight = st.number_input(
                        "Hedef %",
                        min_value=0.0,
                        max_value=100.0,
                        value=float(stock.get('target_weight', 5)),
                        step=1.0,
                        key=f"weight_us_{idx}",
                        label_visibility="collapsed"
                    )
                    config['us_stocks'][idx]['target_weight'] = new_weight
                
                with col4:
                    if st.button("🗑️", key=f"del_us_{idx}"):
                        config['us_stocks'].pop(idx)
                        st.rerun()
        else:
            st.info("Henüz ABD hissesi eklenmedi.")
    
    # =========================================================================
    # TAB 2: KRİPTO
    # =========================================================================
    with tab2:
        st.markdown("### Kripto Paralar")
        
        col1, col2 = st.columns([1, 1])
        
        with col1:
            st.markdown("**Popüler Kripto Paralar:**")
            
            # Grid görünümü
            crypto_cols = st.columns(3)
            for idx, crypto in enumerate(POPULAR_CRYPTOS):
                existing = [c['symbol'] for c in config.get('crypto', [])]
                disabled = crypto['symbol'] in existing
                
                with crypto_cols[idx % 3]:
                    if st.button(
                        f"{crypto['name'][:8]}",
                        key=f"pop_crypto_{crypto['symbol'].replace('/', '_')}",
                        disabled=disabled,
                        help=crypto['symbol'],
                        use_container_width=True
                    ):
                        if 'crypto' not in config:
                            config['crypto'] = []
                        config['crypto'].append({
                            'symbol': crypto['symbol'],
                            'amount': 0.01,
                            'target_weight': 5.0
                        })
                        st.rerun()
        
        with col2:
            st.markdown("**Manuel Ekle:**")
            custom_crypto = st.text_input(
                "Sembol (örn: BTC/USDT)",
                placeholder="TOKEN/USDT",
                key="custom_crypto"
            )
            
            if st.button("Ekle", key="add_custom_crypto"):
                if custom_crypto and "/" in custom_crypto:
                    existing = [c['symbol'] for c in config.get('crypto', [])]
                    if custom_crypto.upper() not in existing:
                        if 'crypto' not in config:
                            config['crypto'] = []
                        config['crypto'].append({
                            'symbol': custom_crypto.upper(),
                            'amount': 0.01,
                            'target_weight': 5.0
                        })
                        st.success(f"{custom_crypto.upper()} eklendi!")
                        st.rerun()
                    else:
                        st.warning("Zaten listede!")
                else:
                    st.error("Geçerli format: TOKEN/USDT")
        
        # Mevcut seçimler
        st.markdown("---")
        st.markdown("### 📋 Seçili Kripto Paralar")
        
        if config.get('crypto'):
            for idx, crypto in enumerate(config['crypto']):
                col1, col2, col3, col4 = st.columns([2, 2, 2, 1])
                
                with col1:
                    st.markdown(f"**{crypto['symbol']}**")
                
                with col2:
                    new_amount = st.number_input(
                        "Miktar",
                        min_value=0.0,
                        value=float(crypto.get('amount', 0.01)),
                        step=0.01,
                        format="%.4f",
                        key=f"amount_crypto_{idx}",
                        label_visibility="collapsed"
                    )
                    config['crypto'][idx]['amount'] = new_amount
                
                with col3:
                    new_weight = st.number_input(
                        "Hedef %",
                        min_value=0.0,
                        max_value=100.0,
                        value=float(crypto.get('target_weight', 5)),
                        step=1.0,
                        key=f"weight_crypto_{idx}",
                        label_visibility="collapsed"
                    )
                    config['crypto'][idx]['target_weight'] = new_weight
                
                with col4:
                    if st.button("🗑️", key=f"del_crypto_{idx}"):
                        config['crypto'].pop(idx)
                        st.rerun()
        else:
            st.info("Henüz kripto para eklenmedi.")
    
    # =========================================================================
    # TAB 3: TEFAS
    # =========================================================================
    with tab3:
        st.markdown("### TEFAS Yatırım Fonları")
        
        col1, col2 = st.columns([1, 1])
        
        with col1:
            st.markdown("**Popüler Fonlar:**")
            
            for fund in POPULAR_TEFAS:
                existing = [f['code'] for f in config.get('tefas_funds', [])]
                disabled = fund['code'] in existing
                
                col_f1, col_f2 = st.columns([1, 4])
                with col_f1:
                    if st.button(
                        fund['code'],
                        key=f"pop_tefas_{fund['code']}",
                        disabled=disabled
                    ):
                        if 'tefas_funds' not in config:
                            config['tefas_funds'] = []
                        config['tefas_funds'].append({
                            'code': fund['code'],
                            'shares': 100.0,
                            'target_weight': 5.0
                        })
                        st.rerun()
                
                with col_f2:
                    st.caption(fund['name'][:35])
        
        with col2:
            st.markdown("**Manuel Ekle:**")
            custom_tefas = st.text_input(
                "Fon Kodu (3 harf)",
                placeholder="Örn: DLY",
                key="custom_tefas",
                max_chars=5
            )
            
            if st.button("Ekle", key="add_custom_tefas"):
                if custom_tefas and len(custom_tefas) >= 2:
                    existing = [f['code'] for f in config.get('tefas_funds', [])]
                    if custom_tefas.upper() not in existing:
                        if 'tefas_funds' not in config:
                            config['tefas_funds'] = []
                        config['tefas_funds'].append({
                            'code': custom_tefas.upper(),
                            'shares': 100.0,
                            'target_weight': 5.0
                        })
                        st.success(f"{custom_tefas.upper()} eklendi!")
                        st.rerun()
                    else:
                        st.warning("Zaten listede!")
                else:
                    st.error("En az 2 karakter girin.")
        
        # Mevcut seçimler
        st.markdown("---")
        st.markdown("### 📋 Seçili TEFAS Fonları")
        
        if config.get('tefas_funds'):
            for idx, fund in enumerate(config['tefas_funds']):
                col1, col2, col3, col4 = st.columns([2, 2, 2, 1])
                
                with col1:
                    st.markdown(f"**{fund['code']}**")
                
                with col2:
                    new_shares = st.number_input(
                        "Pay",
                        min_value=0.0,
                        value=float(fund.get('shares', 100)),
                        step=100.0,
                        key=f"shares_tefas_{idx}",
                        label_visibility="collapsed"
                    )
                    config['tefas_funds'][idx]['shares'] = new_shares
                
                with col3:
                    new_weight = st.number_input(
                        "Hedef %",
                        min_value=0.0,
                        max_value=100.0,
                        value=float(fund.get('target_weight', 5)),
                        step=1.0,
                        key=f"weight_tefas_{idx}",
                        label_visibility="collapsed"
                    )
                    config['tefas_funds'][idx]['target_weight'] = new_weight
                
                with col4:
                    if st.button("🗑️", key=f"del_tefas_{idx}"):
                        config['tefas_funds'].pop(idx)
                        st.rerun()
        else:
            st.info("Henüz TEFAS fonu eklenmedi.")
    
    # =========================================================================
    # TAB 4: KAYDET & ÖZET
    # =========================================================================
    with tab4:
        st.markdown("### 💾 Portföy Özeti & Kaydet")
        
        # Özet hesapla
        total_weight = 0.0
        
        st.markdown("#### Varlık Sayıları")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            us_count = len(config.get('us_stocks', []))
            us_weight = sum(s.get('target_weight', 0) for s in config.get('us_stocks', []))
            st.metric("🇺🇸 ABD Hisseleri", f"{us_count} adet", f"%{us_weight:.0f} ağırlık")
            total_weight += us_weight
        
        with col2:
            crypto_count = len(config.get('crypto', []))
            crypto_weight = sum(c.get('target_weight', 0) for c in config.get('crypto', []))
            st.metric("₿ Kripto", f"{crypto_count} adet", f"%{crypto_weight:.0f} ağırlık")
            total_weight += crypto_weight
        
        with col3:
            tefas_count = len(config.get('tefas_funds', []))
            tefas_weight = sum(f.get('target_weight', 0) for f in config.get('tefas_funds', []))
            st.metric("🇹🇷 TEFAS", f"{tefas_count} adet", f"%{tefas_weight:.0f} ağırlık")
            total_weight += tefas_weight
        
        st.markdown("---")
        
        # Toplam ağırlık kontrolü
        if total_weight == 100:
            st.success(f"✅ Toplam ağırlık: %{total_weight:.0f} (Doğru!)")
        elif total_weight < 100:
            st.warning(f"⚠️ Toplam ağırlık: %{total_weight:.0f} (Eksik: %{100 - total_weight:.0f})")
        else:
            st.error(f"❌ Toplam ağırlık: %{total_weight:.0f} (Fazla: %{total_weight - 100:.0f})")
        
        st.markdown("---")
        
        # Ayarlar
        st.markdown("#### ⚙️ Genel Ayarlar")
        
        col1, col2 = st.columns(2)
        
        with col1:
            risk_free = st.number_input(
                "Risk-Free Rate (%)",
                min_value=0.0,
                max_value=100.0,
                value=float(config.get('settings', {}).get('risk_free_rate', 0.35) * 100),
                step=1.0,
                help="TCMB politika faizi yaklaşık değeri"
            )
            config['settings']['risk_free_rate'] = risk_free / 100
        
        with col2:
            loss_threshold = st.number_input(
                "Satış Uyarı Eşiği (%)",
                min_value=-50.0,
                max_value=0.0,
                value=float(config.get('thresholds', {}).get('weekly_loss_threshold', -4.0)),
                step=1.0,
                help="Haftalık kayıp bu değerin altındaysa satış önerisi"
            )
            config['thresholds']['weekly_loss_threshold'] = loss_threshold
        
        st.markdown("---")
        
        # Kaydet butonu
        col1, col2, col3 = st.columns([1, 2, 1])
        
        with col2:
            if st.button("💾 Config Dosyasını Kaydet", type="primary", use_container_width=True):
                if save_config(config):
                    st.success("✅ Config başarıyla kaydedildi!")
                    st.balloons()
                    
                    # Session state güncelle
                    st.session_state.portfolio_config = config
                    st.session_state.config = None  # Dashboard'un yeniden yüklemesi için
                else:
                    st.error("❌ Kaydetme hatası!")
        
        # Config önizleme
        with st.expander("📄 Config Dosyası Önizleme"):
            st.code(yaml.dump(config, default_flow_style=False, allow_unicode=True), language="yaml")


if __name__ == "__main__":
    st.set_page_config(page_title="Varlık Seçici", layout="wide")
    render_asset_selector()
